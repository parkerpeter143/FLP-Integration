import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-third-party-merchant',
  templateUrl: './add-third-party-merchant.component.html',
  styleUrls: ['./add-third-party-merchant.component.css']
})
export class AddThirdPartyMerchantComponent implements OnInit {
  constructor(private adminService: AdminServiceService, private routes: Router) { }

  ngOnInit() {
    this.adminService.setFromAdminTP(true);
    this.routes.navigateByUrl("/register");
  }
}
