import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Coupon } from '../coupon';

@Component({
  selector: 'app-coupon-generation',
  templateUrl: './coupon-generation.component.html',
  styleUrls: ['./coupon-generation.component.css']
})
export class CouponGenerationComponent implements OnInit {

 coupon:Coupon; 

  constructor(private adminService:AdminServiceService) { }
generateCoupon(coupCode:string,discount:number){
  console.log(coupCode)
  this.coupon=new Coupon();
  this.coupon.coupCode = coupCode
  this.coupon.discount  = discount
  this.adminService.generateCoupon(this.coupon).subscribe();
}
  ngOnInit() {
  }

}
