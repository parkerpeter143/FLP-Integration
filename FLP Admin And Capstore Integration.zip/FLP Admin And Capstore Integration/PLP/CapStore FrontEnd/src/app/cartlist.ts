import { Product } from './product';
import { Customer } from './Customer';

export class Cartlist {
    
    "cartId":string;
    "cartProduct":Product;
    "customer":Customer;
    "qty":number;
}
