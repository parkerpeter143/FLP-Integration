package com.capg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.bean.WishItem;

public interface WishItemDao extends JpaRepository<WishItem, String>{

}
